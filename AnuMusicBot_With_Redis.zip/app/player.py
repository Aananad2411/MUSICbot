import asyncio
from pytgcalls import PyTgCalls
from pytgcalls.types.input_stream import InputStream, AudioPiped
from pytgcalls.types.stream import StreamAudioEnded
from pyrogram import Client
from app.config import API_ID, API_HASH, SESSION
from app.queue import get_next_track
import os

app = Client("AnuMusicBot", api_id=API_ID, api_hash=API_HASH, session_string=SESSION)
vc_client = PyTgCalls(app)

vc_client.start()

@vc_client.on_stream_end()
async def auto_next_handler(_, update: StreamAudioEnded):
    chat_id = update.chat_id
    next_track = get_next_track(chat_id)
    if next_track:
        await join_and_play(chat_id, next_track)
    else:
        await leave_vc(chat_id)

async def join_and_play(chat_id: int, audio_path: str):
    
    await vc_client.join_group_call(

        chat_id,
        InputStream(AudioPiped(audio_path)),
        stream_type="local_stream"
    )

async def leave_vc(chat_id: int):
    await vc_client.leave_group_call(chat_id)

async def pause_stream(chat_id: int):
    await vc_client.pause_stream(chat_id)

async def resume_stream(chat_id: int):
    await vc_client.resume_stream(chat_id)

async def stop_stream(chat_id: int):
    await leave_vc(chat_id)


    # Auto delete audio file
    if os.path.exists(audio_path):
        os.remove(audio_path)
