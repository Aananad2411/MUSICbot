# Placeholder for utility functions
